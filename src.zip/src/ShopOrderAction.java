public enum ShopOrderAction {
    END,
    SORT,
    CHANGE_STATUS,
    ADD;
}
